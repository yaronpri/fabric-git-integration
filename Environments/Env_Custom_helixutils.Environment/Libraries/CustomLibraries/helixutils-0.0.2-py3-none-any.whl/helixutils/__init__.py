"""Provides common tools for developing in Fabric Spark."""

from helixutils import _auth, _dataframe_monkeypatch, helix_fs, helix_icm, helix_read, helix_vault
from helixutils._var import connection, linked_service, spark_logger

_logger = spark_logger.getLogger(__name__)

_auth._set_spark_auth()
_dataframe_monkeypatch.initalize()

__all__ = ["connection", "helix_fs", "helix_icm", "helix_read", "helix_vault", "linked_service"]
