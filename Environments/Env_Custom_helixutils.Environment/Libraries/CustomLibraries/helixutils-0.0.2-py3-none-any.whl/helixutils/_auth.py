"""Module to authenticate to fs sources"""

from helixutils._var import (
    app_data_cert_name,
    app_data_client_id,
    current_tenant_id,
    spark,
    spark_logger,
    vault_url,
)
from helixutils.helix_vault import _get_noncompliant_secret

_logger = spark_logger.getLogger(__name__)


def _set_spark_auth():
    """Set spark configuration for authentication"""
    # fmt: off
    spark.conf.set("fs.azure.account.oauth.provider.type", "com.microsoft.azure.trident.tokenlibrary.AkvBasedClientCertTokenProvider")
    spark.conf.set("fs.azure.account.auth.akv.name", vault_url)
    spark.conf.set("fs.azure.account.auth.akv.certname", app_data_cert_name)
    spark.conf.set("fs.azure.account.auth.client.id", app_data_client_id)
    spark.conf.set("fs.azure.account.auth.tenant.id", current_tenant_id)

    spark.conf.set("spark.hadoop.fs.azure.account.oauth.provider.type", "com.microsoft.azure.trident.tokenlibrary.AkvBasedClientCertTokenProvider")
    spark.conf.set("spark.hadoop.fs.azure.account.auth.akv.name", vault_url)
    spark.conf.set("spark.hadoop.fs.azure.account.auth.akv.certname", app_data_cert_name)
    spark.conf.set("spark.hadoop.fs.azure.account.auth.client.id", app_data_client_id)
    spark.conf.set("spark.hadoop.fs.azure.account.auth.tenant.id", current_tenant_id)

    spark.conf.set("fs.adl.oauth2.access.token.provider.type", "ClientCredential")
    spark.conf.set("fs.adl.account.ipanalytics-prod-c11.oauth2.client.id", app_data_client_id)
    spark.conf.set("fs.adl.account.ipanalytics-prod-c11.oauth2.credential", _get_noncompliant_secret("clientSecret-ipanalytics-app-prod"))
    spark.conf.set("fs.adl.account.ipanalytics-prod-c11.oauth2.refresh.url", f"https://login.microsoftonline.com/{current_tenant_id}/oauth2/token")
    # fmt: on
