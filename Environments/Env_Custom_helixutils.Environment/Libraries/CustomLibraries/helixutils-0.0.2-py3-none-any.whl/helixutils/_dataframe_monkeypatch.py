"""Module to monkey patch spark DataFrame class"""

from datetime import datetime

from delta.tables import DeltaTable
from notebookutils import mssparkutils
from pyspark.sql import DataFrame
from pyspark.sql.functions import col
from pyspark.sql.types import StructField, StructType

from helixutils._var import connection, spark, spark_logger

_logger = spark_logger.getLogger(__name__)


def _select_except(self, *cols_to_exclude):
    all_columns = self.columns
    selected_columns = [col for col in all_columns if col not in cols_to_exclude]
    return self.select(*selected_columns)


def _write_delta(self, target_path, partition_by=None, **options):
    writer = self.write.mode("overwrite").format("delta")

    if partition_by:
        writer = writer.partitionBy(*partition_by)

    if not options:
        writer = writer.option("overwriteSchema", "true")
    else:
        for key, value in options.items():
            writer = writer.option(key, value)

    writer.save(target_path)


def _write_incremental_delta(
    self, target_path, match_columns=None, force_overwrite=False, partition_by=None, **options
):
    def order_schema(schema):
        return StructType([
            StructField(field.name, field.dataType, None) for field in sorted(schema, key=lambda field: field.name)
        ])

    def schema_equal(actual_schema, expected_schema):
        actual_sorted = order_schema(actual_schema)
        expected_sorted = order_schema(expected_schema)
        return actual_sorted == expected_sorted

    if force_overwrite is None:
        force_overwrite = datetime.today().weekday() == 6

    if (
        force_overwrite
        or not DeltaTable.isDeltaTable(spark, target_path)
        or not schema_equal(
            self.schema,
            spark.read.format("delta").load(target_path).schema,
        )
    ):
        _logger.info("Overwriting Delta")
        self.write_delta(target_path, partition_by, **options)

        DeltaTable.forPath(spark, target_path).optimize()
        DeltaTable.forPath(spark, target_path).vacuum()

    else:
        _logger.info("Merging Delta")
        match_columns = self.columns if match_columns is None else match_columns
        match_condition = " AND ".join([f"target.{col} = source.{col}" for col in match_columns])
        target_delta = DeltaTable.forPath(spark, target_path)
        target_delta.alias("target").merge(
            self.alias("source"), match_condition
        ).whenNotMatchedInsertAll().whenNotMatchedBySourceDelete().execute()


def _add_calendar_key(self):
    """For a given dataframe, add Calendar_Key if DIM_DateId is present."""
    if "DIM_DateId" in self.columns:
        return self.selectExpr("*", "TO_DATE(CAST(DIM_DateId AS String), 'yyyyMMdd') AS DIM_CalendarKey")
    return self


def _add_week_number(self):
    """For a given dataframe, add Calendar_Key if DIM_DateId is present."""
    if "DIM_DateId" in self.columns:
        return self.selectExpr(
            "*",
            "FLOOR(DATEDIFF(TO_DATE(CAST(DIM_DateId AS String), 'yyyyMMdd'), TO_DATE('2006-01-01', 'yyyy-MM-dd')) / 7) AS week_number",
        )
    return self


def _replace_alt_key(self, bridge_table, key_name):
    """Checks if a specific column exists in a source table, then constructs a SQL query to replace that column with alternative values from a bridge table"""
    if key_name in self.columns:
        df_bridge = spark.read.format("delta").load(connection["dataprod_default"] + f"/{bridge_table}/")

        key_name_temp = f"{key_name}_temp"

        return (
            self.withColumnRenamed(key_name, key_name_temp)
            .alias("T")
            .join(df_bridge.alias("B"), col(f"T.{key_name_temp}") == col(f"B.{key_name}"), "left")
            .selectExpr(f"COALESCE(B.{key_name}_Alt, -1) AS {key_name}_Alt", "T.*")
            .select_except(key_name_temp)
        )

    return self


def _to_view(self, view_name):
    """Create a temporary view from a DataFrame"""
    self.createOrReplaceTempView(view_name)


def _to_staged_view(self, view_name):
    """Stage the DataFrame first and then create a temporary view"""
    temp_location = connection["temp_default"] + view_name + mssparkutils.runtime.context["currentNotebookName"]
    self.write_parquet(temp_location)
    spark.read.parquet(temp_location).createOrReplaceTempView(view_name)


def _write_partitioned_delta(self, target_path, key_name):
    overwrite_keys = ",".join(map(str, self.select(key_name).distinct().rdd.flatMap(lambda x: x).collect()))
    self.write_delta(target_path, partition_by=[key_name], replaceWhere=f"{key_name} IN ({overwrite_keys})")


# def _write_kpi(self, tpid_present="false", tenant_present="false"):
#     # Load data into DataFrames
#     df_kpi = spark.read.format("delta").load(connection["dataprod_default"] + "/DIM_KPIMetric/")
#     df_calendar = spark.read.format("delta").load(connection["dataprod_default"] + "/DIM_Calendar/")
#     df_account = spark.read.format("delta").load(connection["dataprod_default"] + "/DIM_Account/")
#     df_tenant = spark.read.format("delta").load(connection["dataprod_default"] + "/DIM_Tenant/")

#     # Define constants
#     default_tpid = -100
#     default_tenant_id = "00000000-0000-0000-0000-000000000000"
#     all_tenant_id = "FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF"

#     # Perform joins and transformations
#     result_df = (
#         self.alias("M")
#         .join(df_calendar.alias("D"), "M.DIM_DateId = D.DIM_DateId")
#         .join(df_kpi.alias("K"), "M.DIM_KPIId = K.DIM_KPIId", "left")
#         .join(df_account.alias("A"), f"{'M.DIM_TPID' if tpid_present != "false" else default_tpid} = A.DIM_TPID", "left")
#         .join(df_tenant.alias("T"), f"{'M.DIM_TenantId' if tenant_present != "false" else default_tenant_id} = T.DIM_TenantId", "left")
#         .filter("""
#             M.MeasureValue <> 0
#             AND (
#                 D.CalendarDate >= ADD_MONTHS(TRUNC(CURRENT_DATE, 'MM'), -13)
#                 OR D.CalendarDate = CAST(D.FMEndDate AS DATE)
#             )
#             """
#         )
#         .selectExpr(f"""
#             M.DIM_DateId,
#             M.DIM_KPIId,
#             {default_tpid if tpid_present == "false" else "A.DIM_TPID"} AS DIM_TPID,
#             COALESCE({"'ALL'" if tenant_present == "false" else "T.DIM_TenantId"}, '{all_tenant_id}') AS DIM_TenantId,
#             COALESCE(A.DIM_SubsidiarySubDistrictId, 0) AS DIM_SubsidiarySubDistrictId,
#             COALESCE(A.DIM_SubsidiaryId, 0) AS DIM_SubsidiaryId,
#             COALESCE(A.DIM_SubSegmentId, 0) AS DIM_SubSegmentId,
#             COALESCE(
#                 CAST(CONV(RIGHT(MD5(LOWER(CASE WHEN M.CustomerType = '' THEN 'unknown' ELSE M.CustomerType END)), 16), 16, -10) AS BIGINT),
#                 CAST(CONV(RIGHT(MD5('unknown'), 16), 16, -10) AS BIGINT)
#             ) AS DIM_CustomerTypeId,
#             M.CustomerType,
#             M.ExtendedData,
#             CAST(M.MeasureValue AS DOUBLE) AS MeasureValue,
#             K.DIM_ProductMasterId
#             """
#         )
#     )  # fmt: skip

#     result_df.write_partitioned_delta("FACT_KPI", "DIM_KPIId")


# def _write_okr(self, static_target="true", ignore_date_retention="false"):
#     df_bridge = spark.read.format("delta").load(connection["dataprod_default"] + "/BRIDGE_OKRMetric/")
#     df_calendar = spark.read.format("delta").load(connection["dataprod_default"] + "/DIM_Calendar/")

#     result_df = (
#         self.alias("S")
#         .join(df_bridge.alias("B"), "S.DIM_OKRMetricId = B.DIM_OKRMetricId")
#         .join(df_calendar.alias("C"), "S.DIM_DateId = C.DIM_DateId AND Rolling24MonthFlag = 'True'")
#         .selectExpr(f"""
#             C.DIM_DateId,
#             B.DIM_OKRMetricId,
#             B.DIM_ProductMasterId,
#             B.DIM_ServiceTreeId,
#             S.ExtendedData,
#             CAST(S.MetricActual AS DOUBLE) AS MetricActual,
#             CAST(COALESCE({"B" if static_target == "true" else "S"}.MetricTarget, 0) AS DOUBLE) AS MetricTarget,
#             B.MetricCadence,
#             C.CalendarDate,
#             MAX(C.CalendarDate) OVER (PARTITION BY B.DIM_OKRMetricId) AS MaxDate
#             """)
#         .filter(f"""
#             MetricCadence = 'Monthly' OR
#             '{ignore_date_retention.lower()}' = 'true' OR
#             CalendarDate = MaxDate OR
#             CalendarDate >= date_add(MaxDate, -60) OR
#             CalendarDate = date_add(MaxDate, -365) OR
#             CalendarDate = last_day(CalendarDate)
#             """)
#         .selectExpr("""
#             DIM_DateId,
#             DIM_OKRMetricId,
#             DIM_ProductMasterId,
#             DIM_ServiceTreeId,
#             ExtendedData,
#             MetricActual,
#             MetricTarget,
#             """)
#     )
#     result_df.write_partitioned_delta("FACT_OKR", "DIM_OKRMetricId")


def initalize():
    """Initialize the DataFrame class with custom functions."""
    DataFrame.select_except = _select_except
    DataFrame.write_delta = _write_delta
    DataFrame.write_incremental_delta = _write_incremental_delta
    DataFrame.add_calendar_key = _add_calendar_key
    DataFrame.add_week_number = _add_week_number
    DataFrame.replace_alt_key = _replace_alt_key
