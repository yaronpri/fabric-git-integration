"""Module to store common variables"""

from notebookutils import mssparkutils
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()
spark_logger = spark._jvm.org.apache.log4j.LogManager

_logger = spark_logger.getLogger(__name__)

vault_url = "https://helixdata-keyvault-prod.vault.azure.net/"
app_data_cert_name = "cert-helixdata-app-data-prod"
app_data_client_id = "9ff5e18d-369b-4cdc-bb63-4df9a71c17b6"
current_workspace_id = mssparkutils.runtime.context["currentWorkspaceId"]
current_tenant_id = "72f988bf-86f1-41af-91ab-2d7cd011db47"

current_environment = (
    "prod"
    if current_workspace_id in ["f7436f0f-b175-4421-b9ab-1f6de4175b63", "aac1b554-e482-435e-95dc-266c1db7200b"]
    else "test"
    if current_workspace_id in ["cdc60a10-f1c9-479c-8be7-88992cf52ae2", "de794e10-4e1a-48ba-9a15-d151a4f16dcb"]
    else "dev"
)


def _create_connection_dict():
    """Create connection dictionary for all environments"""
    prod_only_connection = {
        "edl207_fde": "abfss://fde@cseoedlprodadlsg2wus207.dfs.core.windows.net/",
        "abidata": "abfss://abidata@fdestoragereport01.dfs.core.windows.net/",
        "abidatamssales": "abfss://abidatamssales@fdestoragereport01.dfs.core.windows.net/",
        "abidatabizapps": "abfss://abidatabizapps@fdestoragereport01.dfs.core.windows.net/",
        "hrdl": "abfss://subscriptions@hcmlakeprod.dfs.core.windows.net/",
        "ipcosmos": "adl://ipanalytics-prod-c11.azuredatalakestore.net/local/prod/",
        "ipcosmos_shares": "adl://ipanalytics-prod-c11.azuredatalakestore.net/shares/",
        "gpsmart": "abfss://gpsmart@gpsinsightsadlsprd01.dfs.core.windows.net/",
        "gpsprocessed": "abfss://processed@gpsinsightsadlsprd01.dfs.core.windows.net/",
        "meshintake": "abfss://helixfabric-datamesh@msit-onelake.dfs.fabric.microsoft.com/Intake.Lakehouse/",
        "intake": "abfss://helixfabric-prod-storage@msit-onelake.dfs.fabric.microsoft.com/Unified.Lakehouse/Files/Intake/",
        "meshinternal": "abfss://helixfabric-datamesh@msit-onelake.dfs.fabric.microsoft.com/DataMeshInternal.Lakehouse/",
        "pmeintake": "abfss://pme@helixdataintakelakeprod.dfs.core.windows.net/",
        "gpsstaging": "abfss://staging@gpsinsightsadlsprd01.dfs.core.windows.net/",
        "securezone": "abfss://securezone@mssalesfdlakeprod.dfs.core.windows.net/",
        "dwdcp": "abfss://ba61fd34-8ed9-487c-9c46-7e0fbcc37fca@msit-onelake.dfs.fabric.microsoft.com/8df0c8f9-e2d5-42e3-8a81-6371d6471d1a/",
        "datacloudsupportability": "abfss://175c4095-91ef-4286-8be4-47a291c153b7@msit-onelake.dfs.fabric.microsoft.com/0d00d594-ef8b-46b2-b823-9f2902271f65/",
        "pbicat": "abfss://a8761e99-eb56-430e-beec-9459852545a6@msit-onelake.dfs.fabric.microsoft.com/9e14c330-6a66-46b7-b238-0af3f0c284d2/",
        "OCDM": "abfss://ocdm@cseoedlprodadlsg2wus203.dfs.core.windows.net/",
        "OCDM_cdp": "abfss://ocdm@ocdmcdpprdpubpvpoukfpfsc.dfs.core.windows.net/",
        "ideas": "abfss://1f91cdee-e0a3-4955-900c-1912b45a2718@msit-onelake.dfs.fabric.microsoft.com/f7ff8e29-56e6-4c5e-b4bb-792f8867dc31/",
        "xiad": "abfss://4595703d-63e8-436e-8271-99bdf16c5465@msit-onelake.dfs.fabric.microsoft.com/a1221fa9-43a6-436f-a52a-d8aaaf881044/",
    }  # fmt: skip

    connection = {f"{key}_prod": value for key, value in prod_only_connection.items()}

    # create an entry for dev/test/prod in all environments so we can point to other environments for debug efforts
    for e in ["dev", "test", "prod", "default"]:
        name = e
        e = current_environment if e == "default" else e
        # fmt: off
        connection[f"curate_{name}"] = f"abfss://helixfabric-{e}-storage@msit-onelake.dfs.fabric.microsoft.com/Unified.Lakehouse/Tables/Curate/"
        connection[f"dataprod_{name}"] = f"abfss://helixfabric-{e}-storage@msit-onelake.dfs.fabric.microsoft.com/Unified.Lakehouse/Tables/Dataprod/"
        connection[f"adinsights_{name}"] = f"abfss://helixfabric-{e}-storage@msit-onelake.dfs.fabric.microsoft.com/Unified.Lakehouse/Tables/AzureDataInsights/"
        connection[f"operations_{name}"] = f"abfss://helixfabric-{e}-storage@msit-onelake.dfs.fabric.microsoft.com/Unified.Lakehouse/Tables/Operations/"
        connection[f"temp_{name}"] = f"abfss://helixfabric-{e}-storage@msit-onelake.dfs.fabric.microsoft.com/Unified.Lakehouse/Files/Temp/"
        # fmt: on
    return connection


def _create_linked_service_dict():
    """Create linked service dictionary for all environments"""
    _kusto = {
        "chip_userairo_prod": "https://chip.centralus.kusto.windows.net;UserAiro",
        "copilotmetrics_prod": "https://phoenix-telemetry-ame.eastus2.kusto.windows.net;cooking-pipelines",
        # ICM Team "Azure Cosmos DB/Copilot"
        # POC James.Codella@microsoft.com; xingfan@microsoft.com; zhli2@microsoft.com
        "icmdataro_icmdatacommon_prod": "https://icmdataro.centralus.kusto.windows.net;IcmDataCommon",
        "icmdatawarehouse_prod": "https://icmcluster.kusto.windows.net;IcmDataWarehouse",
        "identitydata_prod": "https://idsharedcus.kusto.windows.net;idProductData",
        "s360drilledinfo_ro_prod": "https://s360drilledinfo.kusto.windows.net;s360drilledinforo",
        "usage360_product360_prod": "https://usage360.centralus.kusto.windows.net;Product360",
        "irpaggregates_prod": "https://irpaggregates.northeurope.kusto.windows.net;Irpaggregates",
        "pixal_prod": "https://pixal.kusto.windows.net;Offers-PROD",
        "servicetreepublic_prod": "https://servicetreepublic.westus.kusto.windows.net;Shared",
    }  # fmt: skip

    if current_environment == "prod":
        orch_server = "x6eps4xrq2xudenlfv6naeo3i4-4ifc4lifsuge7k2c45wmch5qpu.msit-database.fabric.microsoft.com"
        orch_database = "Orchestration-bc29e694-5b4d-457b-87d7-6ca6b79de395"
    elif current_environment == "test":
        orch_server = "x6eps4xrq2xudenlfv6naeo3i4-4ifc4lifsuge7k2c45wmch5qpu.msit-database.fabric.microsoft.com"
        orch_database = "Orchestration-e854d3d3-ca30-447d-915c-49b81eb94371"
    else:
        orch_server = "x6eps4xrq2xudenlfv6naeo3i4-4ifc4lifsuge7k2c45wmch5qpu.msit-database.fabric.microsoft.com"
        orch_database = "Orchestration-33d4cfad-ce98-4cc1-be07-0ff9773ba541"

    orch_connection = f"{orch_server};{orch_database}"

    _sql = {
        "pbianalytics_pbianalyticsdm_prod": "PBIAnalytics.database.windows.net;PBIAnalyticsDM",
        "udpcommercial_mst_prod": "udpdatamartmst.database.windows.net;UDPCommercial",
        "dcp_prod": "pbidcpprodsynapsews.sql.azuresynapse.net;pbidcpprodsp",
        "datahub_prod": "datahub1.database.windows.net;DataHub",
        "dwreliability_prod": "dwreliability.database.windows.net;DWReliability",
        "wwl_prod": "wwldeprimarysynapseworkspace-ondemand.sql.azuresynapse.net;Conformed",
        "ipanalytics_orchestration_default": orch_connection,
    }  # fmt: skip

    return _kusto | _sql


connection = _create_connection_dict()
linked_service = _create_linked_service_dict()
