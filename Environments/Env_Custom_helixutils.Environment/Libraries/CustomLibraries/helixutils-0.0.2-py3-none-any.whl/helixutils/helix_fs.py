"""Module to extend mssparkutils.fs"""

import re

from notebookutils import mssparkutils

from helixutils._var import spark_logger

_logger = spark_logger.getLogger(__name__)


def deep_ls(path: str, max_depth=1):
    """Recursively list all files in a directory up to a maximum depth"""

    def _deep_ls_recursive(path: str, max_depth):
        # List all files in path
        li = mssparkutils.fs.ls(path)

        # Return all files
        for x in li:
            if x.size != 0:
                yield x

        # If the max_depth has not been reached, start listing files and folders in subdirectories
        if max_depth > 1:
            for x in li:
                if x.size != 0:
                    continue
                yield from _deep_ls_recursive(x.path, max_depth - 1)

        # If max_depth has been reached, return the folders
        else:
            for x in li:
                if x.size == 0:
                    yield x

    return list(_deep_ls_recursive(path, max_depth))


def deep_ls_filtered(path: str, regex_match, max_depth=1):
    """Recursively list all files in a directory up to a maximum depth that match a regex pattern"""
    deep_list = deep_ls(path, max_depth)
    return [x for x in deep_list if bool(re.fullmatch(regex_match, x.name))]


def exists(path):
    """Check if a path exists"""
    try:
        mssparkutils.fs.ls(path)
        return True
    except:
        return False
