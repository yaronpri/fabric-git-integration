"""Module to support generic functions"""

import base64

import requests
from notebookutils import mssparkutils

from helixutils import helix_vault
from helixutils._var import current_environment, spark_logger

_logger = spark_logger.getLogger(__name__)


def _ran_by_prod_pipeline():
    """Check if in production and ran by pipeline"""
    return not (current_environment != "prod" or not mssparkutils.runtime.context["isForPipeline"])


def create(title, description, severity, fields, owning_team="HelixData/Operations"):
    """Create an IcM Incident"""
    if _ran_by_prod_pipeline():
        # Construct the IcM URL with the secret key
        icm_key = helix_vault.get_secret("key-helixdata-function-createicm")
        icm_url = f"https://helixdata-function-prod.azurewebsites.net/api/create-icm?code={icm_key}"

        # Encode the description
        encoded_description = base64.b64encode(description.encode("utf-8")).decode("utf-8")

        # Prepare the payload
        payload = {
            "title": title,
            "description": encoded_description,
            "symptom": fields,
            "severity": severity,
            "owningTeam": owning_team,
        }

        # Send the POST request
        response = requests.post(icm_url, json=payload)

        # Handle the response
        if response.status_code != 200:
            msg = f"Request failed with status code: {response.status_code}\n{response.text}"
            raise Exception(msg)

        response_data = response.json()
        incident_id = response_data["incidentId"]
        return incident_id.strip()
    return None
