"""Module to read data from various sources"""

import re
from datetime import datetime

from notebookutils import mssparkutils

from helixutils._var import linked_service, spark, spark_logger
from helixutils.helix_vault import get_token

_logger = spark_logger.getLogger(__name__)


def delta(path):
    """Read from delta file to DataFrame object"""
    return spark.read.format("delta").load(path)


def parquet(path):
    """Read from parquet file to DataFrame object"""
    return spark.read.parquet(path)


def sql(script, linked_service_name):
    """Read sql to DataFrame object"""
    server, database = extract_linked_service(linked_service_name)
    return (
        spark.read.format("jdbc")
        .option("url", f"jdbc:sqlserver://{server}:1433;database={database}")
        .option("query", script)
        .option("accessToken", get_token("https://database.windows.net/"))
        .option("encrypt", "true")
        .option("hostNameInCertificate", "*.database.windows.net")
        .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
        .load()
    )


def kusto(script, linked_service_name):
    """Read from Kusto to DataFrame object"""
    server, database = extract_linked_service(linked_service_name)
    return (
        spark.read.format("com.microsoft.kusto.spark.synapse.datasource")
        .option("kustoCluster", server)
        .option("accessToken", get_token("https://kusto.kusto.windows.net/.default"))
        .option("kustoDatabase", database)
        .option("kustoQuery", script)
        .option("readMode", "ForceDistributedMode")
        .load()
    )


def extract_linked_service(linked_service_name):
    """Get linked service details"""
    server = re.split(";", linked_service[linked_service_name])[0]
    database = re.split(";", linked_service[linked_service_name])[1]

    return server, database


def mismatched_schema_parquet(file_path, file_date_regex, file_cutover_date, pre_cutover_schema, post_cutover_schema):
    """Read parquet files with mismatched schema"""
    all_files = mssparkutils.fs.ls(file_path)
    cutover_date = datetime.strptime(file_cutover_date, "%Y-%m-%d")

    pre_cutover_list = []
    post_cutover_list = []

    for x in all_files:
        file_date = datetime.strptime(re.sub(file_date_regex, r"\1", x.path), "%Y_%m_%d")
        if file_date < cutover_date:
            pre_cutover_list.append(x.path)
        else:
            post_cutover_list.append(x.path)

    pre_cutover_df = spark.read.parquet(*pre_cutover_list).selectExpr(*pre_cutover_schema)
    post_cutover_df = spark.read.parquet(*post_cutover_list).selectExpr(*post_cutover_schema)

    return pre_cutover_df.union(post_cutover_df)
