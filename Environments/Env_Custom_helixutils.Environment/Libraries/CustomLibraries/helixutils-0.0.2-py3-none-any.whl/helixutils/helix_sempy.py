"""Module to interact with sempy"""

import sempy.fabric as fabric

from helixutils._var import current_environment


def refresh_table(workspace, semantic_model, table):
    """Refresh semantic model table"""
    fabric.refresh_dataset(
        workspace=workspace, dataset=semantic_model, objects=[{"table": f"{table}"}], refresh_type="full"
    )

    # Return the most recent refresh
    return fabric.list_refresh_requests(dataset=semantic_model, workspace=workspace)[:1]


def refresh_adinsights_table(table):
    """Refresh table in Azure Data Insights"""
    workspace_map = {
        "dev": ("HelixFabric-Dev-Insights", "Azure Data Insights [Dev]"),
        "test": ("HelixFabric-Test-Insights", "Azure Data Insights [Test]"),
        "prod": ("HelixFabric-Insights", "Azure Data Insights"),
    }
    workspace, semantic_model = workspace_map.get(current_environment)
    refresh_table(workspace, semantic_model, table)
