"""Module to interact with tokens and key vault"""

from notebookutils import mssparkutils

from helixutils._var import (
    app_data_cert_name,
    app_data_client_id,
    current_tenant_id,
    spark,
    spark_logger,
    vault_url,
)

_logger = spark_logger.getLogger(__name__)


def get_secret(secret_name):
    """Get secret from key vault"""
    return mssparkutils.credentials.getSecret(vault_url, secret_name)


# TODO Remove for SFI Compliance
def _get_noncompliant_secret(secret_name):
    """Get non-compliant secret from key vault"""
    return mssparkutils.credentials.getSecret("https://ipanalytics-kvault-prod.vault.azure.net/", secret_name)


def get_token(auth_resource):
    """Get AAD token from SPN certificate"""
    internal_token_library = (
        spark._jvm.java.lang.Class.forName("com.microsoft.azure.trident.tokenlibrary.TokenLibrary$")
        .getDeclaredField("MODULE$")
        .get(None)
    )
    internal_token_library.getAADTokenWithClientCertificate(
        auth_resource, current_tenant_id, app_data_client_id, vault_url, app_data_cert_name
    )
